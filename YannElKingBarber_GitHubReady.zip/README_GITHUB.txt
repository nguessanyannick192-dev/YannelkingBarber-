YANN EL KING BARBER — VERSION PRÊTE POUR GITHUB ACTIONS

1. Créer un dépôt GitHub nommé YannElKingBarber.
2. Envoyer tout le contenu de ce dossier dans le dépôt.
3. Ouvrir l'onglet Actions.
4. Choisir "Build Yann El King Barber APK".
5. Appuyer sur "Run workflow".
6. Une fois terminé, ouvrir le workflow réussi et télécharger l'artefact
   "Yann-El-King-Barber-APK".
7. Le fichier app-debug.apk peut ensuite être téléchargé sur Android et installé.

Remarque : Android peut demander d'autoriser l'installation d'applications
depuis cette source. N'installe l'APK que depuis ton propre dépôt/build.
