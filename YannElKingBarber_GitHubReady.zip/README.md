# Yann El King Barber — Application Android

Projet Android Studio prêt à être ouvert dans Android Studio.

## Ce que contient cette version
- Application Android portrait
- Écran d'accueil Yann El King Barber
- Liste des prestations et tarifs
- Réservation : prestation, date, heure, nom et téléphone
- Confirmation de réservation
- Historique local des réservations
- Design noir et doré
- Fonctionne hors ligne (les réservations sont stockées sur l'appareil)

## Ouvrir le projet
1. Installer Android Studio.
2. Ouvrir le dossier `YannElKingBarber`.
3. Laisser Android Studio synchroniser Gradle.
4. Brancher un téléphone Android ou lancer un émulateur.
5. Cliquer sur Run ▶.

## Pour une version professionnelle
Il faudra ensuite connecter les réservations à une base de données en ligne et créer un espace administrateur afin que Yann El King Barber puisse voir et gérer les rendez-vous des clients sur tous les appareils.
