Version PWA Yann El King Barber. Mettre ces 4 fichiers sur GitHub Pages, puis ouvrir le lien dans Chrome et choisir Ajouter à l'écran d'accueil.
